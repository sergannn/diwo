import 'package:flutter/services.dart'
    show
        FilteringTextInputFormatter,
        LengthLimitingTextInputFormatter,
        TextInputFormatter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:email_validator/email_validator.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'animated_widgets.dart';
import 'utils/auth/auth.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  bool _isPhoneValid = false;
  bool _isPhoneFilled = false;
  bool _isUserAvailable = false;

  // Добавляем контроллер для никнейма
  final _nicknameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _phoneController.addListener(() {
      setState(() {
        _isPhoneValid = true; // _validatePhoneNumber(_phoneController.text);
      });
    });
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _nicknameController.dispose();
    super.dispose();
  }

  bool _validatePhoneNumber(String value) {
    String pattern = r'^\+?7\d{10}$';
    RegExp regExp = RegExp(pattern);
    return regExp.hasMatch(value);
  }

  @override
  Widget build(BuildContext context) {
    // Определяем размеры экрана
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Color.fromARGB(255, 2, 14, 24),
      body: SafeArea(
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 600,
              minHeight: MediaQuery.of(context).size.height,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Заголовок "Вход/Регистрация"
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Вход/Регистрация',
                    style: GoogleFonts.montserrat(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: 30),

                // Добавляем изображение
                Image.asset('assets/images/border.png'),
                SizedBox(height: 4), // Отступ после изображения

                // Контейнер с градиентным фоном и светящейся рамкой
                Container(
                  margin: EdgeInsets.only(left: screenWidth * 0.08),
                  padding: EdgeInsets.all(30),
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 2, 14, 24),
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25),
                        bottomLeft: Radius.circular(25)),
                    border: Border.all(color: Color.fromARGB(0, 13, 158, 255)),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF0DA0FF).withOpacity(0.6),
                        spreadRadius: 10,
                        blurRadius: 25,
                        offset: Offset(0, 0),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Секция телефона
                      _buildPhoneSection(),

                      SizedBox(height: 20),

                      // Секция никнейма
                      _buildNicknameSection(),
                    ],
                  ),
                ),

                SizedBox(height: 20),
                // Текст "Войти с помощью"
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Войти с помощью',
                        style: GoogleFonts.montserrat(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF0DA0FF),
                        ),
                      ),
                      SizedBox(width: 20),
                      Image.asset('assets/images/icon_tg.png', width: 52),
                    ],
                  ),
                ),
                SizedBox(height: 80),
                // Кнопки входа и регистрации
                _buildButtonsSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPhoneSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Поле телефона
        TextFormField(
          onChanged: (value) async {
            if (value.length == 11) {
              _isPhoneFilled = true;
              context.loaderOverlay.show();
              // Проверяем только если имя достаточно длинное
              bool isAvailable =
                  await AuthRepository().checkUsernameAvailability(value);
              setState(() {
                _isUserAvailable = isAvailable;
              });
              context.loaderOverlay.hide();
            } else {
              _isPhoneFilled = false;
            }
          },
          controller: _phoneController,
          style: GoogleFonts.inter(
            fontSize: 16,
            color: Colors.white.withOpacity(_isPhoneValid ? 1 : 0.6),
          ),
          decoration: InputDecoration(
            hintText: '+7 000 000 00 01',
            hintStyle: GoogleFonts.inter(
              fontSize: 16,
              color: Colors.grey.shade400,
            ),
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            errorStyle: TextStyle(color: Colors.red),
            errorText: _phoneController.text.isNotEmpty && !_isPhoneValid
                ? 'Введите корректный номер телефона'
                : null,
          ),
          keyboardType: TextInputType.phone,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(11),
            PhoneFormatter(),
          ],
        ),

        // Разделительная линия
        Container(
          height: 2,
          margin: EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Color(0xFF209FFF),
                Color(0xFF0077CD),
              ],
            ),
          ),
        ),

        // Подсказка
        Text(
          'Введите номер телефона',
          style: GoogleFonts.montserrat(
            fontSize: 12,
            fontWeight: FontWeight.w400,
            color: Color.fromARGB(219, 202, 202, 202),
          ),
        ),
        _isPhoneFilled == true
            ? _isUserAvailable == false
                ? Text(
                    "Имя занято",
                    style: GoogleFonts.montserrat(
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: Colors.red),
                  )
                : Text(
                    _isUserAvailable ? "Имя свободно" : "Имя занято",
                    style: GoogleFonts.montserrat(
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: _isUserAvailable
                            ? Colors.green
                            : Colors.red //fromARGB(219, 202, 202, 202),
                        ),
                  )
            : Container()
      ],
    );
  }

  Widget _buildNicknameSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Поле ввода никнейма
        TextFormField(
          controller: _nicknameController,
          style: GoogleFonts.montserrat(
            fontSize: 16,
            color: Colors.white.withOpacity(0.6),
          ),
          decoration: InputDecoration(
            hintText: 'Никнейм',
            hintStyle: GoogleFonts.montserrat(
              fontSize: 16,
              color: Colors.grey.shade400,
            ),
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
          ),
        ),

        // Разделительная линия
        Container(
          height: 2,
          margin: EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Color(0xFF209FFF),
                Color(0xFF0077CD),
              ],
            ),
          ),
        ),
        // Заголовок "Никнейм"
        Text(
          'Введите никнейм',
          style: GoogleFonts.montserrat(
            fontSize: 12,
            fontWeight: FontWeight.w400,
            color: Color.fromARGB(219, 202, 202, 202),
          ),
        ),
        // Подсказка о длине
        Text(
          '*Не более 12 символов',
          style: GoogleFonts.montserrat(
            fontSize: 10,
            fontWeight: FontWeight.w400,
            color: Color(0xFF209FFF),
          ),
        ),
      ],
    );
  }

  Widget _buildButtonsSection() {
    return Column(
      children: [
        // Кнопка входа

        authButton(context, _phoneController),
        SizedBox(height: 20),

        registerButton(context, _phoneController, _nicknameController)
        // Кнопка регистрации
      ],
    );
  }
}

Widget authButton(context, _phoneController) {
  return AnimatedContainer(
    duration: Duration(milliseconds: 200),
    margin: EdgeInsets.symmetric(
        horizontal: MediaQuery.of(context).size.width * 0.1),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Colors.black,
          Color(0xFF014984),
        ],
      ),
      border: Border.all(color: Color(0xFF11A8FD), width: 2),
      borderRadius: BorderRadius.circular(25),
      boxShadow: [
        BoxShadow(
          color: Color(0xFF11A8FD).withOpacity(0.5),
          spreadRadius: 5,
          blurRadius: 15,
          offset: Offset(0, 0),
        ),
      ],
    ),
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        elevation: 0,
        shadowColor: Colors.transparent,
        padding: EdgeInsets.zero,
        minimumSize: Size(double.infinity, 50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
      ),
      onPressed: () {
        Navigator.pushNamed(context, '/login');
      },
      child: Text(
        'Войти',
        style: GoogleFonts.lato(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    ),
  );
}

Widget registerButton(context, _phoneController, _nicknameController) {
  return AnimatedContainer(
    duration: Duration(milliseconds: 200),
    margin: EdgeInsets.symmetric(
        horizontal: MediaQuery.of(context).size.width * 0.1),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Colors.black,
          Color(0xFF014984),
        ],
      ),
      border: Border.all(color: Color(0xFF11A8FD), width: 2),
      borderRadius: BorderRadius.circular(25),
      boxShadow: [
        BoxShadow(
          color: Color(0xFF11A8FD).withOpacity(0.5),
          spreadRadius: 5,
          blurRadius: 15,
          offset: Offset(0, 0),
        ),
      ],
    ),
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        elevation: 0,
        shadowColor: Colors.transparent,
        padding: EdgeInsets.zero,
        minimumSize: Size(double.infinity, 50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
      ),
      onPressed: () async {
        await AuthRepository().register(
            email: _phoneController.text,
            password: "12345",
            username: _nicknameController.text);
        Navigator.pushNamed(context, '/confirmationcode',
            arguments: _nicknameController.text);
      },
      child: Text(
        'Зарегистрироваться',
        style: GoogleFonts.lato(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    ),
  );
}

class PhoneFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    String newText = newValue.text;

    // Если текст начинается с '+', сохраняем его
    if (newText.isNotEmpty &&
        newText[0] == '+' &&
        !oldValue.text.startsWith('+')) {
      newText = '+${newText.substring(1)}';
    }

    // Удаляем все символы кроме цифр и '+'
    newText = newText.replaceAll(RegExp(r'[^\d\+]'), '');

    // Ограничиваем длину до 11 символов (включая '+')
    if (newText.length == 11) {
//      checkUsernameAvailability(newText);
    }
    if (newText.length > 11) {
      newText = newText.substring(0, 11);
    }

    return TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
  }
}
