import 'dart:convert';

import 'package:http/http.dart' as http;

class AuthRepository {
  Future<dynamic> register({
    required String email,
    required String password,
    required String username,
  }) async {
    final response = await http.post(
      Uri.parse("http://www.postagents.ru/api/auth/register"),
      body: {
        'name': username,
        'email': email,
        'password': password,
      },
    );
    print(response.statusCode);
    print(response.body);
    if (response.statusCode == 200) {
      final decodedResponse = jsonDecode(response.body) as Map<String, dynamic>;
      print(decodedResponse);
      //  return SessionModel.fromBackendJson(decodedResponse);
    } else {
      throw Exception('Failed to register');
    }
  }

  Future<dynamic> login({
    required String email,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse("postagents.com/api/auth/login"),
      body: {
        'email': email,
        'password': password,
      },
    );
    if (response.statusCode == 200) {
      final decodedResponse = jsonDecode(response.body) as Map<String, dynamic>;
      print(decodedResponse);
      //return SessionModel.fromBackendJson(decodedResponse);
    } else {
      throw Exception('Failed to login');
    }
  }

  Future<bool> checkUsernameAvailability(String username) async {
    final response = await http.get(
      Uri.parse(
          "https://www.postagents.ru/api/auth/checkusername?username=$username"),
//          "http://www.postagents.com/api/auth/check-username?username=$username"),
    );
    print(response.statusCode);
    if (response.statusCode == 200) {
      final decodedResponse = jsonDecode(response.body) as Map<String, dynamic>;
      print(decodedResponse);
      return decodedResponse['available'];
    } else {
      throw Exception('Failed to check username availability');
    }
  }
}
