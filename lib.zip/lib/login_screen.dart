import 'package:flutter/material.dart';
import 'package:flutter_application_1/profile_screen.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  int _passwordLength = 0;

  @override
  Widget build(BuildContext context) {
    final username = ModalRoute.of(context)?.settings.arguments as String?;
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 2, 14, 24),
      body: SafeArea(
        child: Column(
          children: [
            // Аватар
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.blue.shade200,
                    width: 2,
                  ),
                ),
                child: Icon(
                  Icons.person,
                  color: Colors.blue.shade200,
                  size: 60,
                ),
              ),
            ),

            // Имя
            Text(
              username ?? "Неизвестный",
              style: GoogleFonts.montserrat(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            // Пароль
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    'Пароль',
                    style: GoogleFonts.montserrat(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                  Text(
                    'Задайте пароль для входа',
                    style: GoogleFonts.montserrat(
                      color: Color(0xFF7C7C7C),
                      fontSize: 14,
                    ),
                  ),

                  // Кружочки для пароля
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 50.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(4, (index) {
                        bool isFilled = _passwordLength >
                            index; // Проверяем, заполнен ли кружочек
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isFilled ? Color(0xFF018CFF) : Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: isFilled
                                    ? Color.fromARGB(255, 111, 190, 255)
                                        .withOpacity(
                                            0.5) // Голубое свечение для заполненных кружочков
                                    : Colors.white.withOpacity(
                                        0.5), // Белое свечение для пустых кружочков
                                blurRadius: 24, // Радиус размытия
                                spreadRadius: 10, // Радиус распространения
                              ),
                            ],
                          ),
                        );
                      }),
                    ),
                  ),

                  // Забыли пароль
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Text(
                      'Забыли пароль',
                      style: GoogleFonts.montserrat(
                        color: Color(0xFF7C7C7C),
                        fontSize: 14,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),

                  // Кнопки ввода пароля
                  Column(
                    children: [
                      _buildNumberRow('789'),
                      _buildNumberRow('456'),
                      _buildNumberRow('123'),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 4),
                              width: 89, // Устанавливаем ширину кнопки
                              height: 62, // Устанавливаем высоту кнопки
                              child: Text(
                                'Выйти',
                                style: GoogleFonts.montserrat(
                                  color: Color(0xFF7D7D7D), // Цвет текста
                                  fontSize: 14, // Размер шрифта
                                ),
                              )),
                          Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 4),
                            width: 89, // Устанавливаем ширину кнопки
                            height: 62, // Устанавливаем высоту кнопки
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(
                                      0xFF020518), // Цвет верхнего левого угла
                                  Color(
                                      0xFF061C27), // Цвет нижнего правого угла
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(32),
                              border: Border.all(
                                color: Color.fromARGB(
                                    99, 185, 185, 185), // Цвет обводки
                                width: 0.5,
                              ),
                            ),
                            child: TextButton(
                              onPressed: () {},
                              child: Text(
                                '0',
                                style: GoogleFonts.roboto(
                                  color: Colors.white,
                                  fontSize: 22,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 16),
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color.fromARGB(0, 66, 66, 66),
                            ),
                            child: const Icon(
                              Icons
                                  .arrow_left, // Здесь заменяем на стрелку назад
                              color: Colors.white,
                              size: 40,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Row _buildNumberRow(String numbers) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: numbers.split('').map((number) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          width: 89, // Устанавливаем ширину кнопки
          height: 62, // Устанавливаем высоту кнопки
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF020518), // Цвет верхнего левого угла
                Color(0xFF061C27), // Цвет нижнего правого угла
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(
              color: Color.fromARGB(99, 185, 185, 185), // Цвет обводки
              width: 0.5,
            ),
          ),
          child: TextButton(
            onPressed: () {
              if (_passwordLength < 4) {
                setState(() {
                  _passwordLength++;
                  if (_passwordLength == 4 && number == '1') {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ProfileScreen()),
                    );
                  }
                });
              }
            },
            child: Text(
              number,
              style: GoogleFonts.roboto(
                color: Colors.white,
                fontSize: 22,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
